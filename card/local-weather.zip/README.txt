A Pen created at CodePen.io. You can find this one at http://codepen.io/ermacmk/pen/QNBabG.

 Based on OpenWeatherMap.com API, IP-API.com Geolocation API and Weather Icons.

Forked from [Aleksandr Sidorov](http://codepen.io/AleksandrSidorov/)'s Pen [Local Weather](http://codepen.io/AleksandrSidorov/pen/KdpEpa/).